package dev.musicplayer;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

/**
 * Точка входа мода (только клиент).
 * Регистрирует клавишу M, запускает плеер и открывает экран по нажатию.
 */
public final class MusicPlayerMod implements ClientModInitializer {
    public static final String MOD_ID = "musicplayer";

    private static KeyBinding openKey;

    @Override
    public void onInitializeClient() {
        // С 1.21.9 категория клавиши — объект KeyBinding.Category (перевод: key.category.musicplayer.main)
        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of(MOD_ID, "main"));
        openKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.musicplayer.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_M, category));

        // Читаем конфиг, сканируем папку с музыкой (асинхронно), восстанавливаем громкость/последний трек
        MusicPlayer.get().init();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openKey.wasPressed()) {
                if (client.currentScreen == null && client.player != null) {
                    client.setScreen(new MusicScreen());
                }
            }
        });

        // Сохраняем конфиг и освобождаем аудио при выходе из игры
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> MusicPlayer.get().shutdown());
    }
}
