package dev.musicplayer;

import javazoom.spi.mpeg.sampled.convert.MpegFormatConversionProvider;
import javazoom.spi.mpeg.sampled.file.MpegAudioFileReader;

import javax.sound.sampled.AudioFileFormat;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Stream;

/**
 * Сканирует папку с музыкой и декодирует файлы в PCM для Clip.
 * Поддержка: WAV / AIFF / AU (встроенно) и MP3 (через вшитый mp3spi).
 * Декодер MP3 вызывается напрямую, а не через AudioSystem — так не зависим от SPI-lookup в Knot.
 */
public final class TrackLoader {
    private static final Set<String> EXT = Set.of("wav", "wave", "aif", "aiff", "au", "mp3");

    private TrackLoader() {}

    /** Описание трека. */
    public static final class Track {
        public final Path path;
        public final String fileName;
        public final String title;
        public final String artist;
        /** Длительность в мс; -1 пока неизвестна (уточняется при загрузке). */
        public volatile long durationMs = -1;

        Track(Path path, String title, String artist) {
            this.path = path;
            this.fileName = path.getFileName().toString();
            this.title = title;
            this.artist = artist;
        }
    }

    /** Декодированное аудио. */
    public record Decoded(AudioFormat format, byte[] data) {}

    /** Находит все поддерживаемые файлы (без рекурсии), сортирует по имени. */
    public static List<Track> scan(Path dir) throws IOException {
        List<Track> out = new ArrayList<>();
        if (!Files.isDirectory(dir)) return out;
        try (Stream<Path> s = Files.list(dir)) {
            s.filter(Files::isRegularFile).filter(p -> EXT.contains(ext(p))).forEach(p -> {
                Track t = parse(p);
                probeDuration(t);
                out.add(t);
            });
        }
        out.sort(Comparator.comparing(t -> t.fileName.toLowerCase(Locale.ROOT)));
        return out;
    }

    /** "Исполнитель - Название.mp3" -> artist/title; иначе исполнитель неизвестен. */
    private static Track parse(Path p) {
        String name = p.getFileName().toString();
        int dot = name.lastIndexOf('.');
        if (dot > 0) name = name.substring(0, dot);
        int sep = name.indexOf(" - ");
        if (sep > 0 && sep < name.length() - 3) {
            return new Track(p, name.substring(sep + 3).trim(), name.substring(0, sep).trim());
        }
        return new Track(p, name.trim(), "Неизвестный исполнитель");
    }

    /** Быстро (без декодирования) пытается узнать длительность. */
    private static void probeDuration(Track t) {
        try {
            if (ext(t.path).equals("mp3")) {
                AudioFileFormat ff = new MpegAudioFileReader().getAudioFileFormat(t.path.toFile());
                Object d = ff.properties().get("duration"); // микросекунды
                if (d instanceof Long us) t.durationMs = us / 1000;
            } else {
                AudioFileFormat ff = AudioSystem.getAudioFileFormat(t.path.toFile());
                if (ff.getFrameLength() > 0 && ff.getFormat().getFrameRate() > 0) {
                    t.durationMs = (long) (ff.getFrameLength() * 1000.0 / ff.getFormat().getFrameRate());
                }
            }
        } catch (Throwable ignored) {
            // длительность узнаем позже, при загрузке в Clip
        }
    }

    /** Полностью декодирует файл в 16-bit PCM (вызывать ТОЛЬКО из фонового потока). */
    public static Decoded decode(Path path) throws Exception {
        AudioInputStream in;
        if (ext(path).equals("mp3")) {
            AudioInputStream raw = new MpegAudioFileReader().getAudioInputStream(path.toFile());
            AudioFormat b = raw.getFormat();
            AudioFormat pcm = pcm16(b);
            in = new MpegFormatConversionProvider().getAudioInputStream(pcm, raw);
        } else {
            AudioInputStream raw = AudioSystem.getAudioInputStream(path.toFile());
            AudioFormat b = raw.getFormat();
            boolean ok = b.getEncoding() == AudioFormat.Encoding.PCM_SIGNED && b.getSampleSizeInBits() == 16;
            in = ok ? raw : AudioSystem.getAudioInputStream(pcm16(b), raw);
        }
        try (in) {
            return new Decoded(in.getFormat(), in.readAllBytes());
        }
    }

    private static AudioFormat pcm16(AudioFormat b) {
        int ch = b.getChannels();
        return new AudioFormat(AudioFormat.Encoding.PCM_SIGNED, b.getSampleRate(), 16, ch, ch * 2, b.getSampleRate(), false);
    }

    private static String ext(Path p) {
        String n = p.getFileName().toString().toLowerCase(Locale.ROOT);
        int i = n.lastIndexOf('.');
        return i < 0 ? "" : n.substring(i + 1);
    }
}
