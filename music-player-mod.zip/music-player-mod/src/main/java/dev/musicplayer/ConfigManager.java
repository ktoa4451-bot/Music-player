package dev.musicplayer;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/**
 * Конфиг: config/music-player/config.json (последний трек + громкость).
 * Запись идёт в фоне с «дебаунсом», чтобы перетаскивание слайдера громкости не нагружало диск.
 */
public final class ConfigManager {
    private static final Logger LOG = LoggerFactory.getLogger(MusicPlayerMod.MOD_ID);
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    /** Сериализуемые данные. */
    static final class Data {
        String lastTrack = "";
        float volume = 0.7f;
    }

    private final Path dir = FabricLoader.getInstance().getConfigDir().resolve("music-player");
    private final Path file = dir.resolve("config.json");
    private final Path musicDir = dir.resolve("music");

    private final ScheduledExecutorService io = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "MusicPlayer-Config");
        t.setDaemon(true);
        return t;
    });
    private ScheduledFuture<?> pending;
    private Data data = new Data();

    public Path musicDir() { return musicDir; }

    /** Создаёт папки и читает конфиг (если есть). */
    public synchronized void load() {
        try {
            Files.createDirectories(musicDir);
            if (Files.exists(file)) {
                try (Reader r = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
                    Data d = GSON.fromJson(r, Data.class);
                    if (d != null) data = d;
                }
            }
            data.volume = clamp(data.volume);
            if (data.lastTrack == null) data.lastTrack = "";
        } catch (Exception e) {
            LOG.warn("Не удалось прочитать конфиг плеера", e);
        }
    }

    public synchronized String lastTrack() { return data.lastTrack; }
    public synchronized float volume() { return data.volume; }

    public synchronized void setLastTrack(String name) { data.lastTrack = name == null ? "" : name; saveSoon(); }
    public synchronized void setVolume(float v) { data.volume = clamp(v); saveSoon(); }

    /** Отложенное сохранение (через 400 мс после последнего изменения). */
    public synchronized void saveSoon() {
        if (pending != null) pending.cancel(false);
        pending = io.schedule(this::saveNow, 400, TimeUnit.MILLISECONDS);
    }

    /** Немедленное сохранение. */
    public synchronized void saveNow() {
        try {
            Files.createDirectories(dir);
            Files.writeString(file, GSON.toJson(data), StandardCharsets.UTF_8);
        } catch (Exception e) {
            LOG.warn("Не удалось сохранить конфиг плеера", e);
        }
    }

    private static float clamp(float v) { return Float.isNaN(v) ? 0.7f : Math.max(0f, Math.min(1f, v)); }
}
