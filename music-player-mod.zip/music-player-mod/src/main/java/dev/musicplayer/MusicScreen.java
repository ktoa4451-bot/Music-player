package dev.musicplayer;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.List;

/**
 * Экран плеера. Полностью кастомная отрисовка (без стандартных кнопок/виджетов):
 * скруглённые панели, мягкие тени, неоновые градиенты, плавные анимации.
 * Музыка продолжает играть после закрытия экрана.
 */
public final class MusicScreen extends Screen {
    // ---- палитра (ARGB)
    private static final int CYAN = 0xFF00E5FF, MAGENTA = 0xFFFF2BD6, WHITE = 0xFFFFFFFF;
    private static final int TEXT = 0xFFE8EAF6, DIM = 0xFF8E93A8;
    private static final int ROW_H = 26;

    private final MusicPlayer player = MusicPlayer.get();
    private boolean initialized;

    // ---- анимационное состояние
    private long lastNs;
    private float time, open, gA = 1f, spin;
    private float scroll, scrollTarget, hlY = -1f, trackAnim = 1f;
    private int lastTrackIdx = -2;
    private float[] rowHover = new float[0];
    private float playH, prevH, nextH, closeH, refreshH, progH, volH;
    private boolean dragProg, dragVol, dragScroll;
    private float dragFrac;

    // ---- раскладка (пересчитывается каждый кадр — экран адаптивен)
    private int px, py, pw, ph, lx, ly, lw, lh, rx, rw, progY, btnY, pbX, pbW, volX, volW, cx, rfx, rfy, rfw;

    public MusicScreen() { super(Text.literal("Music Player")); }

    @Override
    protected void init() {
        if (!initialized) { initialized = true; player.reload(); } // подхватить новые файлы при каждом открытии
    }

    @Override
    public boolean shouldPause() { return false; } // игра не ставится на паузу

    // =====================================================================  RENDER

    @Override
    public void render(DrawContext g, int mx, int my, float deltaTicks) {
        long now = System.nanoTime();
        float dt = lastNs == 0 ? 0.016f : Math.min(0.05f, (now - lastNs) / 1e9f);
        lastNs = now;
        time += dt;
        open = approach(open, 1f, dt, 9f);
        gA = open;
        layout();

        List<TrackLoader.Track> tr = player.tracks();
        int cur = player.currentIndex();
        MusicPlayer.State st = player.state();
        boolean playing = st == MusicPlayer.State.PLAYING;
        if (playing) spin += dt * 2.2f;

        if (cur != lastTrackIdx) {            // смена трека -> анимация текста/обложки + автопрокрутка
            lastTrackIdx = cur;
            trackAnim = 0f;
            if (cur >= 0) {
                float y = cur * ROW_H;
                if (y < scrollTarget || y > scrollTarget + lh - ROW_H) scrollTarget = y - lh / 2f + ROW_H / 2f;
            }
        }
        trackAnim = approach(trackAnim, 1f, dt, 6f);
        if (rowHover.length < tr.size()) rowHover = new float[tr.size() + 16];

        // затемнение фона + «пружинящее» появление панели
        g.fill(0, 0, width, height, col(0xA0000000));
        float sc = 0.94f + 0.06f * open;
        g.getMatrices().pushMatrix();
        g.getMatrices().translate(width / 2f, height / 2f);
        g.getMatrices().scale(sc, sc);
        g.getMatrices().translate(-width / 2f, -height / 2f);

        // мягкая тень (несколько слоёв) + тонкая рамка + тело панели
        for (int i = 12; i >= 1; i--) roundRect(g, px - i, py - i + 5, pw + i * 2, ph + i * 2, 14 + i, 0x08000000);
        roundRect(g, px - 1, py - 1, pw + 2, ph + 2, 14, 0x30FFFFFF);
        roundGrad(g, px, py, pw, ph, 13, 0xF00B0D1A, 0xF0171029);
        hGrad(g, px + 14, py, pw - 28, 2, CYAN, MAGENTA, pw - 28);       // неоновая линия сверху

        // заголовок + кнопка закрытия
        text(g, "MUSIC PLAYER", px + 14, py + 11, lerpColor(CYAN, MAGENTA, 0.5f + 0.5f * (float) Math.sin(time)), 1.2f, true);
        boolean hClose = dist(mx, my, px + pw - 18, py + 18) < 10;
        closeH = approach(closeH, hClose ? 1 : 0, dt, 14f);
        circle(g, px + pw - 18, py + 18, 9, lerpColor(0x22FFFFFF, 0xCCFF4466, closeH));
        text(g, "x", px + pw - 20.5f, py + 14, WHITE, 1f, false);

        // ---------------- левая часть: список
        text(g, "ТРЕКИ  " + tr.size(), lx, py + 30, DIM, 0.85f, false);
        boolean hRef = in(mx, my, rfx, rfy, rfw, 14);
        refreshH = approach(refreshH, hRef ? 1 : 0, dt, 14f);
        roundRect(g, rfx, rfy, rfw, 14, 7, lerpColor(0x22FFFFFF, 0x66FFFFFF, refreshH));
        text(g, "Обновить", rfx + 7, rfy + 3.5f, lerpColor(DIM, WHITE, refreshH), 0.8f, false);

        roundRect(g, lx - 4, ly - 4, lw + 8, lh + 8, 9, 0x18FFFFFF);
        float contentH = tr.size() * ROW_H;
        float maxScroll = Math.max(0, contentH - lh);
        scrollTarget = Math.max(0, Math.min(maxScroll, scrollTarget));
        scroll = approach(scroll, scrollTarget, dt, 14f);

        g.enableScissor(lx, ly, lx + lw, ly + lh);
        if (tr.isEmpty()) {
            text(g, "Нет треков", lx + 10, ly + 12, TEXT, 1.1f, true);
            text(g, "Положи .mp3 / .wav в папку:", lx + 10, ly + 30, DIM, 0.8f, false);
            text(g, "config/music-player/music", lx + 10, ly + 42, CYAN, 0.8f, false);
            text(g, "и нажми «Обновить»", lx + 10, ly + 54, DIM, 0.8f, false);
        } else {
            if (cur >= 0) {                                  // плавно «едущая» подсветка активного трека
                float target = cur * ROW_H;
                hlY = hlY < 0 ? target : approach(hlY, target, dt, 12f);
                int hy = ly + Math.round(hlY - scroll);
                roundGrad(g, lx, hy, lw - 8, ROW_H - 2, 7, 0x5000E5FF, 0x50FF2BD6);
                roundGrad(g, lx, hy + 4, 3, ROW_H - 10, 1, CYAN, MAGENTA);
            }
            int first = Math.max(0, (int) (scroll / ROW_H));
            int last = Math.min(tr.size() - 1, (int) ((scroll + lh) / ROW_H));
            for (int i = first; i <= last; i++) {
                TrackLoader.Track t = tr.get(i);
                int y = ly + i * ROW_H - Math.round(scroll);
                boolean act = i == cur;
                boolean hov = !dragScroll && in(mx, my, lx, ly, lw - 8, lh) && in(mx, my, lx, y, lw - 8, ROW_H);
                rowHover[i] = approach(rowHover[i], hov ? 1 : 0, dt, 14f);
                if (rowHover[i] > 0.01f) roundRect(g, lx, y, lw - 8, ROW_H - 2, 7, lerpColor(0x00FFFFFF, 0x24FFFFFF, rowHover[i]));

                if (act && playing) bars(g, lx + 7, y + 17, 3, 10, 2);        // мини-эквалайзер
                else text(g, String.valueOf(i + 1), lx + 8, y + 9, act ? CYAN : DIM, 0.8f, false);

                String dur = fmt(t.durationMs);
                int durW = (int) (textRenderer.getWidth(dur) * 0.8f);
                int maxW = lw - 8 - 26 - durW - 10;
                text(g, trim(t.title, maxW, 1f), lx + 24, y + 4, act ? lerpColor(CYAN, WHITE, 0.35f) : lerpColor(TEXT, WHITE, rowHover[i]), 1f, false);
                text(g, trim(t.artist, maxW, 0.75f), lx + 24, y + 15, DIM, 0.75f, false);
                text(g, dur, lx + lw - 8 - 5 - durW, y + 9, DIM, 0.8f, false);
            }
        }
        g.disableScissor();
        if (maxScroll > 0) {                                  // скроллбар
            int bh = Math.max(20, (int) (lh * lh / contentH));
            int by = ly + (int) ((lh - bh) * (scroll / maxScroll));
            roundRect(g, lx + lw - 5, by, 3, bh, 1, dragScroll ? CYAN : 0x66FFFFFF);
        }

        // ---------------- правая часть: обложка, название, исполнитель
        TrackLoader.Track ct = player.currentTrack();
        int cs = Math.max(48, Math.min(rw - 8, progY - 10 - ly - 38));
        int cvx = rx + (rw - cs) / 2, cvy = ly;
        float saveA = gA;
        gA = saveA * (0.35f + 0.65f * trackAnim);
        drawCover(g, ct, cvx, cvy, cs, playing);
        float slide = (1f - trackAnim) * 8f;
        gA = saveA * trackAnim;
        String title = ct == null ? "Выбери трек" : ct.title;
        String artist = ct == null ? "из списка слева" : ct.artist;
        float ts = 1.15f;
        String tt = trim(title, (int) (rw / ts), ts);
        text(g, tt, rx + (rw - textRenderer.getWidth(tt) * ts) / 2f, cvy + cs + 8 + slide, WHITE, ts, true);
        String at = trim(artist, (int) (rw / 0.9f), 0.9f);
        text(g, at, rx + (rw - textRenderer.getWidth(at) * 0.9f) / 2f, cvy + cs + 22 + slide, DIM, 0.9f, false);
        gA = saveA;

        // ---------------- низ: прогресс, кнопки, громкость
        g.fill(px + 14, progY - 12, px + pw - 14, progY - 11, col(0x14FFFFFF));
        float frac = dragProg ? dragFrac : player.progress();
        long len = player.lengthMs();
        boolean hProg = dragProg || in(mx, my, pbX - 4, progY - 6, pbW + 8, 14);
        progH = approach(progH, hProg ? 1 : 0, dt, 14f);
        int bh = Math.round(4 + 2 * progH);
        int by2 = progY + 2 - bh / 2;
        roundRect(g, pbX, by2, pbW, bh, bh / 2, 0x30FFFFFF);
        int fw = Math.max(bh, (int) (pbW * frac));
        hGrad(g, pbX, by2, fw, bh, CYAN, MAGENTA, pbW);
        if (progH > 0.02f) {                                  // «ручка» + свечение при наведении
            circle(g, pbX + fw, progY + 2, Math.round(9 * progH), 0x2200E5FF);
            circle(g, pbX + fw, progY + 2, Math.round(5 * progH), WHITE);
        }
        text(g, fmt(Math.round(frac * Math.max(0, len))), px + 14, progY - 2, DIM, 0.8f, false);
        String endT = fmt(len);
        text(g, endT, px + pw - 14 - textRenderer.getWidth(endT) * 0.8f, progY - 2, DIM, 0.8f, false);

        // prev / play / next
        boolean hPrev = dist(mx, my, cx - 46, btnY) < 13, hNext = dist(mx, my, cx + 46, btnY) < 13, hPlay = dist(mx, my, cx, btnY) < 18;
        prevH = approach(prevH, hPrev ? 1 : 0, dt, 14f);
        nextH = approach(nextH, hNext ? 1 : 0, dt, 14f);
        playH = approach(playH, hPlay ? 1 : 0, dt, 14f);
        int pc = lerpColor(DIM, WHITE, prevH), nc = lerpColor(DIM, WHITE, nextH);
        int sk = 1 + Math.round(prevH);
        fillI(g, cx - 46 - 7, btnY - 6, 2, 12, pc);
        tri(g, cx - 46 + 1, btnY, 6 + sk - 1, false, pc);
        sk = 1 + Math.round(nextH);
        fillI(g, cx + 46 + 5, btnY - 6, 2, 12, nc);
        tri(g, cx + 46 - 1, btnY, 6 + sk - 1, true, nc);

        int pr = Math.round(15 + 3 * playH);
        float pulse = playing ? 0.6f + 0.4f * (float) Math.sin(time * 3f) : 0.5f;
        for (int k = 7; k >= 1; k--) circle(g, cx, btnY, pr + k, withAlpha(lerpColor(CYAN, MAGENTA, 0.5f), (int) (14 * pulse * (8 - k) / 7f)));
        circleGrad(g, cx, btnY, pr, CYAN, MAGENTA);
        if (st == MusicPlayer.State.PLAYING) { fillI(g, cx - 5, btnY - 6, 4, 12, 0xFF0B0D1A); fillI(g, cx + 1, btnY - 6, 4, 12, 0xFF0B0D1A); }
        else if (st == MusicPlayer.State.LOADING) {           // «спиннер» загрузки
            for (int i = 0; i < 8; i++) {
                double a = time * 6 + i * Math.PI / 4;
                circle(g, cx + (int) Math.round(Math.cos(a) * 7), btnY + (int) Math.round(Math.sin(a) * 7), 1, withAlpha(0xFF0B0D1A, 60 + i * 24));
            }
        } else tri(g, cx - 2, btnY, 7, true, 0xFF0B0D1A);

        // статус слева
        String stat = player.error() != null ? player.error() : switch (st) {
            case LOADING -> "Загрузка...";
            case PLAYING -> "Играет";
            case PAUSED -> "Пауза";
            default -> "Остановлено";
        };
        text(g, trim(stat, Math.max(30, cx - 70 - (px + 14)), 0.8f), px + 14, btnY - 3, player.error() != null ? 0xFFFF6677 : DIM, 0.8f, false);

        // громкость
        boolean hVol = dragVol || in(mx, my, volX - 22, btnY - 9, volW + 26, 18);
        volH = approach(volH, hVol ? 1 : 0, dt, 14f);
        float v = player.volume();
        int ic = lerpColor(DIM, WHITE, volH);
        fillI(g, volX - 20, btnY - 3, 3, 6, ic);
        tri(g, volX - 15, btnY, 4, false, ic);
        for (int i = 0; i < 3; i++) if (v > i * 0.33f + 0.05f) fillI(g, volX - 8 + i * 3, btnY - 2 - i, 1, 4 + i * 2, ic);
        int vh = Math.round(4 + 2 * volH);
        roundRect(g, volX, btnY - vh / 2, volW, vh, vh / 2, 0x30FFFFFF);
        hGrad(g, volX, btnY - vh / 2, Math.max(vh, (int) (volW * v)), vh, CYAN, MAGENTA, volW);
        if (volH > 0.02f) {
            circle(g, volX + (int) (volW * v), btnY, Math.round(5 * volH), WHITE);
            text(g, Math.round(v * 100) + "%", volX + volW - 14, btnY - 17, DIM, 0.75f, false);
        }

        g.getMatrices().popMatrix();
    }

    /** Процедурная обложка: градиент по хэшу имени + крутящаяся виниловая пластинка + эквалайзер. */
    private void drawCover(DrawContext g, TrackLoader.Track t, int x, int y, int s, boolean playing) {
        int c1, c2;
        if (t == null) { c1 = 0xFF2A2F4A; c2 = 0xFF121528; }
        else {
            float h = (t.fileName.hashCode() & 0x7fffffff) % 360 / 360f;
            c1 = 0xFF000000 | java.awt.Color.HSBtoRGB(h, 0.65f, 0.95f);
            c2 = 0xFF000000 | java.awt.Color.HSBtoRGB((h + 0.18f) % 1f, 0.85f, 0.5f);
        }
        for (int i = 10; i >= 1; i--) roundRect(g, x - i, y - i + 3, s + 2 * i, s + 2 * i, 12 + i, withAlpha(c1, 5)); // цветное свечение
        roundGrad(g, x, y, s, s, 12, c1, c2);

        int cxx = x + s / 2, cyy = y + s / 2, R = (int) (s * 0.36f);
        circle(g, cxx + 2, cyy + 3, R, 0x44000000);
        circle(g, cxx, cyy, R, 0xFF0A0A10);
        circle(g, cxx, cyy, (int) (R * 0.85f), 0xFF14141C);
        circle(g, cxx, cyy, (int) (R * 0.80f), 0xFF0A0A10);
        circle(g, cxx, cyy, (int) (R * 0.62f), 0xFF13131B);
        circle(g, cxx, cyy, (int) (R * 0.58f), 0xFF0A0A10);
        circleGrad(g, cxx, cyy, (int) (R * 0.38f), c1, c2);
        circle(g, cxx, cyy, Math.max(1, (int) (R * 0.06f)), 0xFF0A0A10);
        for (int k = 0; k < 2; k++) {                          // вращающиеся «блики»
            double a = spin + k * Math.PI;
            circle(g, cxx + (int) Math.round(Math.cos(a) * R * 0.7), cyy + (int) Math.round(Math.sin(a) * R * 0.7), 2, 0x66FFFFFF);
        }
        int n = Math.max(6, s / 8), bw = Math.max(2, (s - 16) / n - 2);   // эквалайзер внизу
        for (int i = 0; i < n; i++) {
            float amp = playing ? 0.2f + 0.8f * Math.abs((float) Math.sin(time * (2.2f + i * 0.41f) + i * 1.7f)) : 0.12f;
            int bh = Math.max(2, (int) (s * 0.16f * amp));
            roundRect(g, x + 8 + i * (bw + 2), y + s - 6 - bh, bw, bh, 1, 0xAAFFFFFF);
        }
    }

    // =====================================================================  INPUT

    @Override
    public boolean mouseClicked(Click c, boolean doubled) {
        if (c.button() != 0) return false;
        double mx = c.x(), my = c.y();
        List<TrackLoader.Track> tr = player.tracks();
        if (dist(mx, my, px + pw - 18, py + 18) < 10) { close(); return true; }
        if (in(mx, my, rfx, rfy, rfw, 14)) { player.reload(); return true; }
        if (dist(mx, my, cx, btnY) < 18) { player.togglePause(); return true; }
        if (dist(mx, my, cx - 46, btnY) < 13) { player.prev(); return true; }
        if (dist(mx, my, cx + 46, btnY) < 13) { player.next(); return true; }
        if (in(mx, my, pbX - 4, progY - 6, pbW + 8, 14)) { dragProg = true; dragFrac = fracAt(mx); return true; }
        if (in(mx, my, volX - 22, btnY - 9, volW + 26, 18)) { dragVol = true; player.setVolume(volAt(mx)); return true; }
        if (in(mx, my, lx, ly, lw, lh)) {
            if (mx > lx + lw - 10 && tr.size() * ROW_H > lh) { dragScroll = true; scrollFromMouse(my); return true; }
            int idx = (int) ((my - ly + scroll) / ROW_H);
            if (idx >= 0 && idx < tr.size()) { player.play(idx); return true; }
        }
        return super.mouseClicked(c, doubled);
    }

    @Override
    public boolean mouseDragged(Click c, double dx, double dy) {
        if (dragProg) { dragFrac = fracAt(c.x()); return true; }
        if (dragVol) { player.setVolume(volAt(c.x())); return true; }
        if (dragScroll) { scrollFromMouse(c.y()); return true; }
        return super.mouseDragged(c, dx, dy);
    }

    @Override
    public boolean mouseReleased(Click c) {
        boolean was = dragProg || dragVol || dragScroll;
        if (dragProg) player.seek(dragFrac);                   // перемотка применяется при отпускании
        dragProg = dragVol = dragScroll = false;
        return was || super.mouseReleased(c);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        if (in(mx, my, volX - 22, btnY - 9, volW + 26, 18)) { player.setVolume(player.volume() + (float) vAmount * 0.05f); return true; }
        scrollTarget -= (float) vAmount * ROW_H * 1.5f;
        return true;
    }

    @Override
    public boolean keyPressed(KeyInput in) {
        switch (in.key()) {
            case GLFW.GLFW_KEY_M -> { close(); return true; }
            case GLFW.GLFW_KEY_SPACE -> { player.togglePause(); return true; }
            case GLFW.GLFW_KEY_RIGHT -> { player.next(); return true; }
            case GLFW.GLFW_KEY_LEFT -> { player.prev(); return true; }
            case GLFW.GLFW_KEY_UP -> { player.setVolume(player.volume() + 0.05f); return true; }
            case GLFW.GLFW_KEY_DOWN -> { player.setVolume(player.volume() - 0.05f); return true; }
            case GLFW.GLFW_KEY_R -> { player.reload(); return true; }
            default -> { return super.keyPressed(in); } // ESC закрывает экран штатно
        }
    }

    private float fracAt(double mx) { return (float) Math.max(0, Math.min(1, (mx - pbX) / pbW)); }
    private float volAt(double mx) { return (float) Math.max(0, Math.min(1, (mx - volX) / volW)); }
    private void scrollFromMouse(double my) {
        float max = Math.max(0, player.tracks().size() * ROW_H - lh);
        scrollTarget = (float) Math.max(0, Math.min(1, (my - ly) / lh)) * max;
    }

    // =====================================================================  LAYOUT & HELPERS

    private void layout() {
        pw = Math.min(580, width - 16);
        ph = Math.min(312, height - 16);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        int pad = 14;
        lx = px + pad;
        ly = py + 46;
        lw = Math.max(130, (int) ((pw - pad * 3) * 0.40f));
        progY = py + ph - 62;
        btnY = py + ph - 32;
        lh = progY - 14 - ly;
        rx = lx + lw + pad + 4;
        rw = px + pw - pad - rx;
        pbX = px + pad + 34;
        pbW = pw - pad * 2 - 68;
        cx = px + pw / 2;
        volW = 70;
        volX = px + pw - pad - volW;
        rfw = (int) (textRenderer.getWidth("Обновить") * 0.8f) + 14;
        rfx = lx + lw - rfw;
        rfy = py + 26;
    }

    private static float approach(float cur, float target, float dt, float speed) {
        return cur + (target - cur) * (1f - (float) Math.exp(-speed * dt));
    }
    private static boolean in(double mx, double my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    private static double dist(double ax, double ay, double bx, double by) { return Math.hypot(ax - bx, ay - by); }

    private static String fmt(long ms) {
        if (ms < 0) return "--:--";
        long s = ms / 1000;
        return String.format("%d:%02d", s / 60, s % 60);
    }

    private String trim(String s, int maxW, float scale) {
        int limit = (int) (maxW / scale);
        if (textRenderer.getWidth(s) <= limit) return s;
        return textRenderer.trimToWidth(s, Math.max(0, limit - textRenderer.getWidth(".."))) + "..";
    }

    // ---- цвет
    /** Применяет глобальную прозрачность (анимация появления/смены трека). */
    private int col(int argb) { return (Math.round((argb >>> 24) * gA) << 24) | (argb & 0xFFFFFF); }
    private static int withAlpha(int argb, int a) { return (Math.max(0, Math.min(255, a)) << 24) | (argb & 0xFFFFFF); }
    private static int lerpColor(int a, int b, float t) {
        t = Math.max(0, Math.min(1, t));
        int r = 0;
        for (int sh = 24; sh >= 0; sh -= 8) r |= (Math.round(((a >>> sh) & 255) * (1 - t) + ((b >>> sh) & 255) * t) & 255) << sh;
        return r;
    }

    // ---- примитивы
    private void text(DrawContext g, String s, float x, float y, int color, float scale, boolean shadow) {
        int c = col(color);
        if ((c >>> 24) < 8 || s.isEmpty()) return; // у MC альфа ~0 трактуется как непрозрачный
        g.getMatrices().pushMatrix();
        g.getMatrices().translate(x, y);
        g.getMatrices().scale(scale, scale);
        g.drawText(textRenderer, s, 0, 0, c, shadow);
        g.getMatrices().popMatrix();
    }

    private void fillI(DrawContext g, int x, int y, int w, int h, int color) { g.fill(x, y, x + w, y + h, col(color)); }

    private static int inset(int r, int i) {
        double d = r - i - 0.5;
        return (int) Math.round(r - Math.sqrt(Math.max(0, r * r - d * d)));
    }

    /** Скруглённый прямоугольник без перекрытия строк (корректно с полупрозрачностью). */
    private void roundRect(DrawContext g, int x, int y, int w, int h, int r, int color) {
        int c = col(color);
        if ((c >>> 24) == 0 || w <= 0 || h <= 0) return;
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        for (int i = 0; i < r; i++) {
            int in = inset(r, i);
            g.fill(x + in, y + i, x + w - in, y + i + 1, c);
            g.fill(x + in, y + h - 1 - i, x + w - in, y + h - i, c);
        }
        if (h - 2 * r > 0) g.fill(x, y + r, x + w, y + h - r, c);
    }

    /** Скруглённый прямоугольник с вертикальным градиентом. */
    private void roundGrad(DrawContext g, int x, int y, int w, int h, int r, int c1, int c2) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        for (int j = 0; j < h; j++) {
            int in = j < r ? inset(r, j) : (j >= h - r ? inset(r, h - 1 - j) : 0);
            int c = col(lerpColor(c1, c2, h <= 1 ? 0 : j / (float) (h - 1)));
            g.fill(x + in, y + j, x + w - in, y + j + 1, c);
        }
    }

    /** Горизонтальный градиент; span — ширина всего градиента (для частично заполненных баров). */
    private void hGrad(DrawContext g, int x, int y, int w, int h, int c1, int c2, int span) {
        for (int i = 0; i < w; i += 2)
            g.fill(x + i, y, x + Math.min(i + 2, w), y + h, col(lerpColor(c1, c2, i / (float) Math.max(1, span))));
    }

    private void circle(DrawContext g, int cx0, int cy0, int r, int color) {
        int c = col(color);
        if ((c >>> 24) == 0 || r <= 0) return;
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.round(Math.sqrt(Math.max(0, r * r - dy * dy)));
            g.fill(cx0 - dx, cy0 + dy, cx0 + dx, cy0 + dy + 1, c);
        }
    }

    private void circleGrad(DrawContext g, int cx0, int cy0, int r, int c1, int c2) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.round(Math.sqrt(Math.max(0, r * r - dy * dy)));
            g.fill(cx0 - dx, cy0 + dy, cx0 + dx, cy0 + dy + 1, col(lerpColor(c1, c2, (dy + r) / (2f * r))));
        }
    }

    /** Треугольник-стрелка (play/next вправо, prev/громкость влево); s — «полувысота». */
    private void tri(DrawContext g, int x, int y, int s, boolean right, int color) {
        int c = col(color);
        for (int dy = -s; dy <= s; dy++) {
            int w = Math.round(s * 1.7f * (1f - Math.abs(dy) / (float) (s + 1)));
            if (right) g.fill(x - s / 2, y + dy, x - s / 2 + w, y + dy + 1, c);
            else g.fill(x + s / 2 - w, y + dy, x + s / 2, y + dy + 1, c);
        }
    }

    /** Мини-эквалайзер (n столбцов) для активной строки списка. */
    private void bars(DrawContext g, int x, int baseY, int n, int maxH, int w) {
        for (int i = 0; i < n; i++) {
            int h = 2 + Math.round((maxH - 2) * Math.abs((float) Math.sin(time * (3f + i * 1.3f) + i)));
            fillI(g, x + i * (w + 1), baseY - h, w, h, CYAN);
        }
    }
}
