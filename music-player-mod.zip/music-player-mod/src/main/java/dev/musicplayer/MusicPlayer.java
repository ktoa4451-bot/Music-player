package dev.musicplayer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.LineEvent;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Ядро плеера (синглтон): плейлист, состояние, громкость, javax.sound.sampled.Clip.
 * Все тяжёлые операции (скан папки, декодирование) идут в фоновых потоках,
 * поэтому игра не подвисает. Геттеры потокобезопасны и дешёвы — их зовёт GUI каждый кадр.
 */
public final class MusicPlayer {
    public enum State { STOPPED, LOADING, PLAYING, PAUSED }

    private static final Logger LOG = LoggerFactory.getLogger(MusicPlayerMod.MOD_ID);
    private static final MusicPlayer INSTANCE = new MusicPlayer();
    public static MusicPlayer get() { return INSTANCE; }

    /** Активный клип + счётчик «наших» остановок (чтобы отличить паузу от конца трека). */
    private static final class Active {
        final Clip clip;
        final FloatControl gain;
        final AtomicInteger expectedStops = new AtomicInteger();
        Active(Clip c) {
            clip = c;
            gain = c.isControlSupported(FloatControl.Type.MASTER_GAIN)
                    ? (FloatControl) c.getControl(FloatControl.Type.MASTER_GAIN) : null;
        }
    }

    private final ConfigManager config = new ConfigManager();
    private final ExecutorService playExec = daemon("MusicPlayer-Audio");
    private final ExecutorService scanExec = daemon("MusicPlayer-Scan");
    private final AtomicInteger token = new AtomicInteger(); // инвалидирует устаревшие загрузки

    private volatile List<TrackLoader.Track> tracks = List.of();
    private volatile int current = -1;
    private volatile State state = State.STOPPED;
    private volatile float volume = 0.7f;
    private volatile Active active;
    private volatile String error;
    private boolean restored;

    private MusicPlayer() {}

    private static ExecutorService daemon(String name) {
        return Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, name);
            t.setDaemon(true);
            return t;
        });
    }

    // ------------------------------------------------------------ lifecycle

    public void init() {
        config.load();
        volume = config.volume();
        reload();
    }

    public void shutdown() {
        token.incrementAndGet();
        stopActive();
        config.saveNow();
    }

    /** Пересканировать папку музыки (асинхронно). Текущий трек сохраняется по пути файла. */
    public void reload() {
        scanExec.submit(() -> {
            try {
                List<TrackLoader.Track> found = TrackLoader.scan(config.musicDir());
                TrackLoader.Track cur = currentTrack();
                tracks = found;
                if (cur != null) {
                    int i = indexOf(found, cur.fileName);
                    current = i;
                    if (i < 0) { token.incrementAndGet(); stopActive(); state = State.STOPPED; }
                } else if (!restored) {
                    restored = true;
                    current = indexOf(found, config.lastTrack()); // выбран, но не играет
                }
            } catch (Exception e) {
                LOG.warn("Ошибка сканирования музыки", e);
            }
        });
    }

    private static int indexOf(List<TrackLoader.Track> l, String fileName) {
        for (int i = 0; i < l.size(); i++) if (l.get(i).fileName.equals(fileName)) return i;
        return -1;
    }

    // ------------------------------------------------------------ controls

    public void play(int idx) {
        List<TrackLoader.Track> list = tracks;
        if (idx < 0 || idx >= list.size()) return;
        final TrackLoader.Track track = list.get(idx);
        final int tk = token.incrementAndGet();
        stopActive();
        current = idx;
        state = State.LOADING;
        error = null;
        config.setLastTrack(track.fileName);

        playExec.submit(() -> {
            try {
                TrackLoader.Decoded d = TrackLoader.decode(track.path);
                if (tk != token.get()) return; // пользователь уже выбрал другой трек
                Clip clip = AudioSystem.getClip();
                int len = d.data().length - d.data().length % Math.max(1, d.format().getFrameSize());
                clip.open(d.format(), d.data(), 0, len);
                Active a = new Active(clip);
                clip.addLineListener(ev -> {
                    if (ev.getType() != LineEvent.Type.STOP) return;
                    if (a.expectedStops.get() > 0) { a.expectedStops.decrementAndGet(); return; }
                    // Остановка, которую мы не вызывали = трек доиграл до конца -> следующий
                    if (a == active && tk == token.get()) playExec.submit(() -> { if (tk == token.get()) next(); });
                });
                track.durationMs = clip.getMicrosecondLength() / 1000;
                applyGain(a);
                if (tk != token.get()) { clip.close(); return; }
                active = a;
                clip.start();
                state = State.PLAYING;
            } catch (Throwable e) {
                if (tk == token.get()) {
                    state = State.STOPPED;
                    error = "Не удалось воспроизвести: " + e.getClass().getSimpleName();
                }
                LOG.warn("Ошибка воспроизведения {}", track.fileName, e);
            }
        });
    }

    public void togglePause() {
        Active a = active;
        if (state == State.PLAYING && a != null) {
            a.expectedStops.incrementAndGet();
            a.clip.stop();
            state = State.PAUSED;
        } else if (state == State.PAUSED && a != null) {
            a.clip.start();
            state = State.PLAYING;
        } else if (state == State.STOPPED && !tracks.isEmpty()) {
            play(current >= 0 ? current : 0);
        }
    }

    public void next() {
        int n = tracks.size();
        if (n > 0) play((current + 1) % n);
    }

    public void prev() {
        int n = tracks.size();
        if (n == 0) return;
        if (positionMs() > 3000) seek(0f); // как в обычных плеерах: сперва в начало трека
        else play(((current <= 0 ? n : current) - 1) % n);
    }

    /** @param fraction 0..1 */
    public void seek(float fraction) {
        Active a = active;
        if (a == null) return;
        long len = a.clip.getMicrosecondLength();
        a.clip.setMicrosecondPosition(Math.max(0, Math.min(len - 50_000, (long) (len * Math.max(0f, Math.min(1f, fraction))))));
    }

    public void setVolume(float v) {
        volume = Math.max(0f, Math.min(1f, v));
        Active a = active;
        if (a != null) applyGain(a);
        config.setVolume(volume);
    }

    private void applyGain(Active a) {
        if (a.gain == null) return;
        float db = volume <= 0.001f ? a.gain.getMinimum() : (float) (20.0 * Math.log10(volume));
        a.gain.setValue(Math.max(a.gain.getMinimum(), Math.min(a.gain.getMaximum(), db)));
    }

    private void stopActive() {
        Active a = active;
        active = null;
        if (a == null) return;
        try {
            if (a.clip.isRunning()) { a.expectedStops.incrementAndGet(); a.clip.stop(); }
            a.clip.close();
        } catch (Exception ignored) {}
    }

    // ------------------------------------------------------------ getters (для GUI)

    public List<TrackLoader.Track> tracks() { return tracks; }
    public int currentIndex() { return current; }
    public State state() { return state; }
    public float volume() { return volume; }
    public String error() { return error; }

    public TrackLoader.Track currentTrack() {
        List<TrackLoader.Track> l = tracks;
        int c = current;
        return c >= 0 && c < l.size() ? l.get(c) : null;
    }

    public long positionMs() {
        Active a = active;
        return a == null ? 0 : a.clip.getMicrosecondPosition() / 1000;
    }

    public long lengthMs() {
        Active a = active;
        if (a != null) return a.clip.getMicrosecondLength() / 1000;
        TrackLoader.Track t = currentTrack();
        return t == null ? -1 : t.durationMs;
    }

    public float progress() {
        long len = lengthMs();
        return len <= 0 ? 0f : Math.max(0f, Math.min(1f, positionMs() / (float) len));
    }
}
